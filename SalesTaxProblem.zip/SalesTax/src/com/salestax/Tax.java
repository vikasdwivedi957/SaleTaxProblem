package com.salestax;

public abstract class Tax implements Products {
	
	protected Products products;

	protected double rate;

	abstract double getRate();

	public Tax(Products products){
	this.products = products;
	}

	public double getPrice(){
		double salesTax = Utility.nearTo5Percent(this.products.getProductInitPrice() * this.getRate());
		return Utility.roundOffPrice(this.products.getProductPrice() + salesTax);
	}
}
