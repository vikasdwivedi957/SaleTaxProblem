package com.salestax;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashSet;
import java.util.Set;

public class Utility {

	private static Set<String> exemptProducts = null;
	static	{
		exemptProducts = new HashSet<String>();
		exemptProducts.add("book");
		exemptProducts.add("headache pills");
		exemptProducts.add("packet of headache pills");
		exemptProducts.add("box of imported chocolates");
		exemptProducts.add("imported box of chocolates");
		exemptProducts.add("box of chocolates");
		exemptProducts.add("chocolate");
		exemptProducts.add("chocolate bar");
		exemptProducts.add("pills");
	}
	static public double nearTo5Percent(double amount) {

		return new BigDecimal(Math.ceil(amount * 20)/20).setScale(2,RoundingMode.HALF_UP).doubleValue();

	}

	public static double roundOffPrice(double amount) {

		return new BigDecimal(amount).setScale(2, RoundingMode.HALF_UP)
				.doubleValue();

	}
	
	public static boolean isExemptProduct(String name) {
		return exemptProducts.contains(name);
	}
	
	public static void getInfoFromFile(String fileName) {
		ShoppingBucket sb = new ShoppingBucket();
		try {
		    BufferedReader in = new BufferedReader(new FileReader(fileName));
		    String str;
		    while ((str = in.readLine()) != null) {
		    	if (ProductsParser.matches(str) && !str.isEmpty())
		    		sb.put(ProductsParser.parser(str), ProductsParser.count(str)); 
		    		else
		    			if (!str.isEmpty()) System.out.println("unknown line format: " + str);
		    }
		    in.close();
		} catch (IOException e) {
			System.out.println("error:" + e.getMessage());
			return;
		}
		sb.printOrderInput();
		sb.printOrderResults();
	}
}
