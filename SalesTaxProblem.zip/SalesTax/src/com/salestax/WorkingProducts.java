package com.salestax;

public class WorkingProducts implements Products {
	
	private String productName;
	private boolean isImportedProduct = false;
	private boolean isExemptProduct = false;
	private double productInItPrice;
	
	public WorkingProducts(String productName, double productInItPrice) {
		this.productName = productName;
		this.productInItPrice = productInItPrice;
	}
	
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public boolean getIsImportedProduct() {
		return isImportedProduct;
	}

	public void setIsImportedProduct(boolean isImportedProduct) {
		this.isImportedProduct = isImportedProduct;
	}

	public boolean getIsExemptProduct() {
		return isExemptProduct;
	}

	public void setIsExemptProduct(boolean isExemptProduct) {
		this.isExemptProduct = isExemptProduct;
	}

	public void setInitPrice(double price) {
		this.productInItPrice = price;
	}

	public double getInitPrice() {
		return this.productInItPrice;
	}
	
	@Override
	public int hashCode() {
		return productName.hashCode() + new Integer((int) (productInItPrice * 100));
	}
	@Override
	public boolean equals(Object obj) {

		if (obj == null) {
			return false;
		} else if (obj instanceof Products) {
			return (((Products) obj).hashCode() == this.hashCode());

		} else
			return false;
	}

	@Override
	public double getProductPrice() {
		return this.productInItPrice;
	}

	@Override
	public double getProductInitPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isImportedProduct() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isExemptProduct() {
		// TODO Auto-generated method stub
		return false;
	}
}
