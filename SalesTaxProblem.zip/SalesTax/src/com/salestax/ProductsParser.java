package com.salestax;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProductsParser {

	private static final String PRODUCT_DESCRIPTION_REGEX = "(\\d+)\\s((\\w+\\s)+)at\\s(\\d+.\\d+)";
	
	public static Products parser(String productOrder) {
		Matcher m = parse(productOrder);
		String name = m.group(2).trim();
		WorkingProducts products = new WorkingProducts(name, Double.valueOf(m.group(4)));
		if (name.contains("imported"))
			products.setIsImportedProduct(true);
		if (Utility.isExemptProduct(name))
			products.setIsExemptProduct(true);
		return products;
	}

	public static int count (String productOrder) {
		return Integer.valueOf(parse(productOrder).group(1));
	}
	
	public static Matcher parse(String productDescription) {
		Pattern pattern = Pattern.compile(PRODUCT_DESCRIPTION_REGEX);
		Matcher matcher = pattern.matcher(productDescription);
		matcher.find();
		return matcher;
	}
	
	public static boolean matches(String productDescription) {
		return Pattern.matches(PRODUCT_DESCRIPTION_REGEX, productDescription);
	}
}
