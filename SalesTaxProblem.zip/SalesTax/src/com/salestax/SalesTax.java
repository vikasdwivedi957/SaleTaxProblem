package com.salestax;

public class SalesTax extends Tax {
	
	private Products products;

	final double rate = 0.1;

	public SalesTax(Products products) {
		super(products);
		this.products = products;
	}

	@Override
	double getRate() {
		return this.rate;
	}

	@Override
	public int hashCode() {
		return this.getProductName().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (obj instanceof Products) {
			return (((Products) obj).hashCode() == this.hashCode());

		} else
			return false;
	}

	@Override
	public boolean isExemptProduct() {
		return products.isExemptProduct();
	}
	
	public boolean isImportedProduct() {
		return products.isImportedProduct();
	}

	public String getProductName() {
		return products.getProductName();
	}

	public double getProductInitPrice() {
		return products.getProductInitPrice();
	}

	@Override
	public double getProductPrice() {
		// TODO Auto-generated method stub
		return 0;
	}
}
