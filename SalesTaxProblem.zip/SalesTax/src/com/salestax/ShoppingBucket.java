package com.salestax;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ShoppingBucket {

private final Map<Products, Integer> productsMap = new HashMap<Products, Integer>();
	
	DecimalFormat df = new DecimalFormat("###.00");

	public void put (Products products, int count){
		if (products.isImportedProduct()) products = new ImportTax(products);
		if (!products.isExemptProduct()) products = new SalesTax(products);
		Integer i = this.productsMap.get(products); 
		if ( i!= null) count += i;
		this.productsMap.put(products, count);
	}
	
	public void remove (Products products) {
		this.productsMap.remove(products);
	}
	
	public void clear () {
		this.productsMap.clear();
	}
	
	public Set<Products> getProducts() {
		return productsMap.keySet();
	}
	
	public int getQuantity(Products products){
		return productsMap.get(products);	
	}
	
	public double getTaxtotal() {
		double taxtotal = 0;
		for (Products products : productsMap.keySet()){		
			double subTotal = products.getProductPrice() * getQuantity(products);
			double subInitTotal = products.getProductInitPrice() * getQuantity(products);
			taxtotal += subTotal - subInitTotal;
		}
		return taxtotal;
	}

	public double getTotal() {
		double total = 0;
		for (Products products : productsMap.keySet()){		
			double subTotal = products.getProductPrice() * getQuantity(products);
			total += subTotal;
		}
		return Utility.roundOffPrice(total);
	}

	public void printOrderInput() {
		System.out.println("Order input: ");
		for (Products products : productsMap.keySet() ){
			System.out.println(productsMap.get(products) + " " + products.getProductName() + " at " + df.format(products.getProductInitPrice()));
		}	
		System.out.println();
	}
	
	public void printOrderResults() {	
		double taxtotal = 0;
		double total = 0;
		System.out.println("Order results: ");
		Set<Products> taxedProducts = productsMap.keySet();
		for (Products products : taxedProducts){		
			double subTotal = products.getProductPrice() * getQuantity(products);
			double subInitTotal = products.getProductInitPrice() * getQuantity(products);
			taxtotal += subTotal - subInitTotal;
			total += subTotal;
			System.out.println(getQuantity(products) + " " + products.getProductName() + ": " + df.format(subTotal));
		}
		total = Utility.roundOffPrice(total);
		System.out.println("Sales Taxes: "+df.format(taxtotal));
		System.out.println("Total: "+df.format(total));
		System.out.println();
	}
	
	public static void main(String[] args)
	{
	    if(args.length == 0)
	    {
	        System.exit(0);
	    }
	    for (String fileName: args) Utility.getInfoFromFile(fileName);
	}
}
