package com.salestax;

public interface Products {
	
	String getProductName();

	double getProductInitPrice();

	boolean isImportedProduct();

	boolean isExemptProduct();

	double getProductPrice();

}
